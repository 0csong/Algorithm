
#pragma once

#include "ga.h"


struct chromosome pop1[POPULATION_SIZE], pop2[POPULATION_SIZE];
struct chromosome* pop = pop1, * pop_next = pop2;
struct chromosome best;

double cdf_wheel[POPULATION_SIZE];//�̸� ���� ����(�귿��)�� ���ؼ� ����

void init_pop();
void ga_impl();
void evaluate(struct chromosome* f);
int select(double f_sum);
void crossover(int i1, int i2);
void mutation();
void print_result(double f_sum);
bool get_best();
void make_wheel(double fitness_sum);

int generations;
double weight= 6.0/225.0; //8��Ʈ ����[0,255]�� x,y ����[-3,3]�� ������ ���� ����ġ, 6/255=0.0235294

void print_chromosome(int idx) {
	int i;
	printf("x%d:", idx);
	for (i = 0; i < GENES; i++)
		printf("%d ", pop[idx].genes[i]);
	printf("\n");
}
void print_population() {
	int i;

	printf("solution population\n");
	for (i = 0; i < POPULATION_SIZE; i++)
		print_chromosome(i);
}
void copy_genes(int dest[], int src[]) {
	for (int i = 0; i < GENES; i++)
		dest[i] = src[i];
}
void init_pop() {
	int i, j;

	for (i = 0; i < POPULATION_SIZE; i += 2) {
		for (j = 0; j < GENES; j++) {
			if (rand() % 2) {
				pop[i].genes[j] = 1;
				pop[i + 1].genes[j] = 0;
			}
			else {
				pop[i].genes[j] = 0;
				pop[i + 1].genes[j] = 1;
			}
		}
	}
	print_population();

	for (int i = 0; i < POPULATION_SIZE; i++)
		evaluate(pop + i);

	best.fitness = 0;
	get_best();

	double fitness_sum = 0.0;
	for (i = 0; i < POPULATION_SIZE; i++)
		fitness_sum += pop[i].fitness;
	print_result(fitness_sum);
}

void ga_impl() {
	int i;
	int count = 0;
	double fitness_sum= 0.0;
	struct chromosome* pop_temp;

	while (count < GA_END) {
		generations++;

		fitness_sum = 0.0;
		for (i = 0; i < POPULATION_SIZE; i++)
			fitness_sum += pop[i].fitness;

		if (generations % 10 == 0)
			print_result(fitness_sum);

		make_wheel(fitness_sum); //�̸� ���� ����(�귿��)�� ����
		for (i = 0; i < POPULATION_SIZE; i++)
			pop_next[i] = pop[select(fitness_sum)];

		SWAP(pop, pop_next, pop_temp);

		for (i = 0; i < POPULATION_SIZE; i += 2) {
			if (drand() <= PCROSS)
				crossover(i, i + 1);
		}

		mutation();

		for (i = 0; i < POPULATION_SIZE; i++)
			evaluate(pop + i);

		if (get_best())
			count = 0;
		else {
			count++;
			pop[0] = best;
		}
	}

	print_result(fitness_sum);
}

bool get_best() {
	bool flag = false;
	for (int i = 0; i < POPULATION_SIZE; i++) {
		if (best.fitness < pop[i].fitness) {
			best = pop[i];
			flag = true;
		}
	}
	return flag;
}
void evaluate(chromosome* f) {
	int i;
	int w ;
	int x, y;

	w = 1;
	y = 0;
	for (i = GENES - 1; i >= 8; i--) {
		y += f->genes[i] * w;
		w *= 2;
	}
	w = 1;
	x = 0;
	for ( ; i >= 0; i--) {
		x += f->genes[i] * w;
		w *= 2;
	}
	f->x = x * weight - 3.;
	f->y = y * weight - 3.;
	double x_2 = pow(f->x, 2);
	double x_3 = x_2 * f->x;
	double y_2 = pow(f->y, 2);
	double y_3 = y_2 * f->y;

	f->fitness = pow(1 - f->x, 2) * exp(-x_2 - pow(f->y + 1, 2)) - (f->x - x_3 - y_3) * exp(-x_2 - y_2);
}
void print_result(double f_sum) {
	printf("generation: %d, fitness avg: %f\n", generations, (double)f_sum / POPULATION_SIZE);
	printf("best-max: x:%f, y:%f, f(x):%f\n", best.x, best.y, best.fitness);
}

void mutation() {
	for (int i = 0; i < POPULATION_SIZE; i++) {
		for (int j = 0; j < GENES; j++) {
			if (drand() <= PMUT) {
				if (pop[i].genes[j] == 0)
					pop[i].genes[j] = 1;
				else
					pop[i].genes[j] = 0;
			}
		}
	}
}
void crossover(int i1, int i2) {
	int tmp;
	int point = random(1, GENES);

	for (int i = point; i < GENES; i++)
		SWAP(pop[i1].genes[i], pop[i2].genes[i], tmp);
}

void make_wheel(double fitness_sum) {
	cdf_wheel[0] = pop[0].fitness;
	for (int i = 1; i < POPULATION_SIZE; i++)
		cdf_wheel[i] = cdf_wheel[i-1]+ pop[i].fitness;
}
int select(double f_sum) {
	int i;
	double r;

	r = drand() * f_sum;

	for (i = 0; i < POPULATION_SIZE; i++) {
		if (r <= cdf_wheel[i])
			return i;
	}
	return POPULATION_SIZE - 1;
}