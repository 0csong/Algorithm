
#pragma once

#include "ga.h"

int schedule_base[PLANTS][BASES][QUARTERS] = { //7�� ��ġ�� ���� �б⺰ �����Ȳ
	{ { 1, 1, 0, 0 }, { 0, 1, 1, 0 }, { 0, 0, 1, 1 } },
	{ { 1, 1, 0, 0 }, { 0, 1, 1, 0 }, { 0, 0, 1, 1 } },
	{ { 1, 0, 0, 0 }, { 0, 1, 0, 0 }, { 0, 0, 1, 0 }, { 0, 0, 0, 1 } },
	{ { 1, 0, 0, 0 }, { 0, 1, 0, 0 }, { 0, 0, 1, 0 }, { 0, 0, 0, 1 } },
	{ { 1, 0, 0, 0 }, { 0, 1, 0, 0 }, { 0, 0, 1, 0 }, { 0, 0, 0, 1 } },
	{ { 1, 0, 0, 0 }, { 0, 1, 0, 0 }, { 0, 0, 1, 0 }, { 0, 0, 0, 1 } },
	{ { 1, 0, 0, 0 }, { 0, 1, 0, 0 }, { 0, 0, 1, 0 }, { 0, 0, 0, 1 } }
};
int MW_base[PLANTS] = { 20, 15, 35, 40, 15, 15, 10 };
int base_num[PLANTS] = { 3, 3, 4, 4, 4, 4, 4 }; //�� ��ġ�� ���� �ʿ��� ����� ��
int tot_MW = 150;
int max_MW[QUARTERS] = { 80, 90, 65, 70 }; //�б⺰ �ִ����
int cdf_wheel[POPULATION_SIZE]; //�̸� ���� ����(�귿��)�� ���ؼ� ����

struct chromosome pop1[POPULATION_SIZE], pop2[POPULATION_SIZE];
struct chromosome* pop = pop1, * pop_next = pop2;
struct chromosome best;

void init_pop();
void ga_impl();
void evaluate(struct chromosome* f);
int select(int f_sum);
void crossover(int i1, int i2);
void mutation();
void print_result(int f_sum);
void print_chromosome(chromosome* pch);
bool get_best();
void make_wheel(int fitness_sum);

int generations;

void copy_genes(int dest[], int src[]) {
	for (int i = 0; i < GENES; i++)
		dest[i] = src[i];
}
void init_pop() {
	int i, j;

	for (i = 0; i < POPULATION_SIZE; i++)
		for (j = 0; j < GENES; j++)
			pop[i].genes[j] = rand() % base_num[j];

	for (int i = 0; i < POPULATION_SIZE; i++)
		evaluate(pop + i);


	best.fitness = 0;
	get_best();

	int fitness_sum = 0;
	for (i = 0; i < POPULATION_SIZE; i++)
		fitness_sum += pop[i].fitness;
	print_result(fitness_sum);
}

void ga_impl() {
	int i;
	int count = 0;
	int fitness_sum;
	struct chromosome* pop_temp;

	while (count < GA_END) {
		generations++;

		fitness_sum = 0;
		for (i = 0; i < POPULATION_SIZE; i++)
			fitness_sum += pop[i].fitness;

		if (generations % 10 == 0)
			print_result(fitness_sum);

		make_wheel(fitness_sum); //�̸� ���� ����(�귿��)�� ����

		for (i = 0; i < POPULATION_SIZE; i++)
			pop_next[i] = pop[select(fitness_sum)];

		SWAP(pop, pop_next, pop_temp);

		for (i = 0; i < POPULATION_SIZE; i += 2) {
			if (drand() <= PCROSS)
				crossover(i, i + 1);
		}

		mutation();

		for (i = 0; i < POPULATION_SIZE; i++)
			evaluate(pop + i);

		if (get_best())
			count = 0;
		else {
			count++;
			pop[0] = best;
		}
	}

	print_result(fitness_sum);
	print_chromosome(&best);
}

bool get_best() {
	bool flag = false;
	for (int i = 0; i < POPULATION_SIZE; i++) {
		if (best.fitness < pop[i].fitness) {
			best = pop[i];
			flag = true;
		}
	}
	return flag;
}

void evaluate(chromosome* pch) {
	int power[4];
	int i, j, idx;

	pch->fitness = tot_MW;
	for (i = 0; i < QUARTERS; i++) {
		power[i] = 0;
		for (j = 0; j < PLANTS; j++) {
			idx = pch->genes[j];
			power[i] += schedule_base[j][idx][i]*MW_base[j];
		}
		power[i] = tot_MW - power[i] - max_MW[i];
		if (power[i] < 0) {
			pch->fitness = 0;
			break;
		}
		else if (power[i] < pch->fitness)
			pch->fitness = power[i];
	}
}
void print_result(int f_sum) {
	int f_fitness;

	printf("generation: %d, fitness avg: %.1f\n", generations, (double)f_sum / POPULATION_SIZE);
	f_fitness = 0;
	for (int i = 0; i < POPULATION_SIZE; i++) {
		if (f_fitness < pop[i].fitness) {
			f_fitness = pop[i].fitness;
		}
	}
	printf("max fitness: %d\n", f_fitness);
}

void print_chromosome(chromosome* pch) {
	for (int i = 0; i < PLANTS; i++)
		printf("��ġ%d ", i + 1);
	printf("\n");
	for (int i = 0; i < PLANTS; i++) {
		for (int j = 0; j < QUARTERS; j++)
			printf("%d", schedule_base[i][best.genes[i]][j]);
		printf("  ");
	}
	printf("\n");
}

void mutation() {
	for (int i = 0; i < POPULATION_SIZE; i++) {
		for (int j = 0; j < GENES; j++) {
			if (drand() <= PMUT) {
				pop[i].genes[j] = rand() % base_num[j];
				evaluate(pop + i);
			}
		}
	}
}

void crossover(int i1, int i2) {
	int tmp;
	int point = random(1, GENES);

	for (int i = point; i < GENES; i++)
		SWAP(pop[i1].genes[i], pop[i2].genes[i], tmp);

	evaluate(pop + i1);
	evaluate(pop + i2);
}

void make_wheel(int fitness_sum) {
	cdf_wheel[0] = pop[0].fitness;
	for (int i = 1; i < POPULATION_SIZE; i++)
		cdf_wheel[i] = cdf_wheel[i - 1] + pop[i].fitness;
}

int select(int f_sum) {
	int i;
	double r;

	r = drand() * f_sum;
	for (i = 0; i < POPULATION_SIZE - 1; i++) {
		if (r <= cdf_wheel[i])
			return i;
	}
	return POPULATION_SIZE - 1;
}
